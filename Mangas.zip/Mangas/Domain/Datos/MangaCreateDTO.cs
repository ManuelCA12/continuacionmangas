namespace Mangas.Domain.Datos;

class MangaCreateDto
{
    public string Title { get; set; } = null;
    public string Author { get; set; } = null;
}
